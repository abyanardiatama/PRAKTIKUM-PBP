<!--
  Abyan Ardiatama
  24060120140161
  Praktikum PBP 5
-->
<?php
	//menampilkan waktu server
	echo date('H:i:s');
?>