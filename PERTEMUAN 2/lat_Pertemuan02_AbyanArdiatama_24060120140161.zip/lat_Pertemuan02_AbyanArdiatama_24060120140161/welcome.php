<!--Abyan Ardiatama-->
<!--24060120140161-->
<!--Prak PBP B2-->
<html> 
    <head>
        <title>Hello World</title> 
    </head>
    <body>
        <?php
        echo "<h2>Selamat Datang di Praktikum PBP</h2>";
        echo"Hari ini Praktikum : \"Sintaks Dasar PHP\"";
        ?> 
    </body>
</html>